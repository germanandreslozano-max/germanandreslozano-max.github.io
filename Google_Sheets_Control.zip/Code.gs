const SPREADSHEET_NAME = 'Inscripciones Semana Empresarial 2026';
const SHEET_NAME = 'Inscripciones';
const HEADERS = ['Código', 'Fecha de inscripción', 'Nombre completo', 'Correo electrónico', 'Celular', 'Perfil', 'Programa / empresa / institución', 'Municipio', 'Evento', 'Observaciones', 'Estado', 'Autorización de datos'];

function setup() {
  const properties = PropertiesService.getScriptProperties();
  let id = properties.getProperty('SHEET_ID');
  let ss = id ? SpreadsheetApp.openById(id) : null;
  if (!ss) {
    ss = SpreadsheetApp.create(SPREADSHEET_NAME);
    properties.setProperty('SHEET_ID', ss.getId());
  }
  let sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) sheet = ss.insertSheet(SHEET_NAME);
  if (sheet.getLastRow() === 0) {
    sheet.getRange(1, 1, 1, HEADERS.length).setValues([HEADERS]);
    sheet.setFrozenRows(1);
    sheet.getRange(1, 1, 1, HEADERS.length).setFontWeight('bold').setBackground('#06396d').setFontColor('#ffffff');
    sheet.autoResizeColumns(1, HEADERS.length);
  }
  let token = properties.getProperty('ADMIN_TOKEN');
  if (!token) {
    token = Utilities.getUuid().replace(/-/g, '') + Utilities.getUuid().replace(/-/g, '');
    properties.setProperty('ADMIN_TOKEN', token);
  }
  Logger.log('ENLACE PRIVADO A LA HOJA: ' + ss.getUrl());
  Logger.log('CLAVE PRIVADA DEL PANEL: ' + token);
  return 'Sistema listo. Copia el enlace de la hoja y la clave del panel del registro de ejecución.';
}

function doGet(e) {
  if (e && e.parameter && e.parameter.panel === '1') {
    return HtmlService.createHtmlOutputFromFile('Admin').setTitle('Panel de inscripciones · Semana Empresarial');
  }
  return HtmlService.createHtmlOutputFromFile('Site').setTitle('Semana Empresarial 2026 · UNIMINUTO Girardot');
}

function submitRegistration(data) {
  if (!data || typeof data !== 'object') throw new Error('No se recibieron los datos del formulario.');
  const required = ['name', 'email', 'phone', 'profile', 'city', 'event'];
  required.forEach(function (key) {
    if (!String(data[key] || '').trim()) throw new Error('Completa todos los campos obligatorios.');
    if (String(data[key]).length > 500) throw new Error('Uno de los campos supera el tamaño permitido.');
  });
  const consent = String(data.consent || '').toLowerCase();
  if (consent !== 'on' && consent !== 'true') throw new Error('Se requiere autorización para el tratamiento de datos.');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(data.email))) throw new Error('Verifica el formato del correo electrónico.');
  const sheet = getSheet_();
  const code = 'EXPO-2026-' + Utilities.getUuid().slice(0, 6).toUpperCase();
  const row = [
    code, new Date(), safeCell_(data.name), safeCell_(data.email), safeCell_(data.phone),
    safeCell_(data.profile), safeCell_(data.organization), safeCell_(data.city),
    safeCell_(data.event), safeCell_(data.message), 'Inscrito', 'Sí'
  ];
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try { sheet.appendRow(row); } finally { lock.releaseLock(); }
  return {ok:true, code:code};
}

function getDashboardData(token) {
  assertAdmin_(token);
  const sheet = getSheet_();
  if (sheet.getLastRow() < 2) return [];
  const rows = sheet.getRange(2, 1, sheet.getLastRow() - 1, HEADERS.length).getDisplayValues();
  return rows.reverse().map(function (r) {
    return {code:r[0], date:r[1], name:r[2], email:r[3], phone:r[4], profile:r[5], organization:r[6], city:r[7], event:r[8], message:r[9], status:r[10], consent:r[11]};
  });
}

function updateRegistrationStatus(token, code, status) {
  assertAdmin_(token);
  const allowed = ['Inscrito', 'Asistió', 'Canceló'];
  if (allowed.indexOf(status) === -1) throw new Error('Estado no permitido.');
  const sheet = getSheet_();
  if (sheet.getLastRow() < 2) throw new Error('No hay registros.');
  const codes = sheet.getRange(2, 1, sheet.getLastRow() - 1, 1).getDisplayValues();
  for (let i = 0; i < codes.length; i++) {
    if (codes[i][0] === code) {
      sheet.getRange(i + 2, 11).setValue(status);
      return true;
    }
  }
  throw new Error('No se encontró la inscripción.');
}

function resetAdminToken_() {
  const token = Utilities.getUuid().replace(/-/g, '') + Utilities.getUuid().replace(/-/g, '');
  PropertiesService.getScriptProperties().setProperty('ADMIN_TOKEN', token);
  Logger.log('NUEVA CLAVE PRIVADA DEL PANEL: ' + token);
  return 'Clave renovada. Revisa el registro de ejecución.';
}

function getSheet_() {
  const id = PropertiesService.getScriptProperties().getProperty('SHEET_ID');
  if (!id) throw new Error('Primero ejecuta setup() en Apps Script.');
  const ss = SpreadsheetApp.openById(id);
  const sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) throw new Error('No se encontró la pestaña de inscripciones.');
  return sheet;
}

function assertAdmin_(token) {
  const expected = PropertiesService.getScriptProperties().getProperty('ADMIN_TOKEN');
  if (!expected || !token || String(token) !== expected) throw new Error('Acceso denegado. Verifica la clave privada del panel.');
}

function safeCell_(value) {
  let text = String(value || '').trim().slice(0, 1000);
  if (/^[=+@\-\t\r]/.test(text)) text = "'" + text;
  return text;
}
